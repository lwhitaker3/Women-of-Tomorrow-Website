<?php use Roots\Sage\Titles; ?>

<div class="page-header">
  <div class="line-container"><h1><?= Titles\title(); ?></h1></div>
</div>
