<?php
/**
 * Template Name: Chapter Sponsors
 */
?>

<?php get_template_part('templates/page', 'intro'); ?>
